MileCheck milepost dataset, sample: Utah
Prepared November 2026 by MileCheck LLC (sales@milecheckapp.com). Evaluation use only.

Files: milecheck-mileposts-sample-UT-2026-10.csv and .geojson (same rows, WGS84, EPSG:4326)
Rows: 7487 positions for 5578 markers. 903 markers have a separate position for each side of the road.

Fields
state           two-letter state code
route           signed route, normalized (I-15, US-89, SR-201)
mile            the number on the marker
direction       NB, SB, EB or WB, the side of the road the marker stands on
lat, lon        marker position
position_type   physical marker location
source          the agency layer the position comes from

Source and attribution
Utah: UGRC Reference Posts (SGID), Utah Geospatial Resource Center. CC BY 4.0, credit UGRC.

The full dataset covers all 50 states, about 397,000 positions, refreshed monthly. The fields are the same. In other states, position_type says whether a position is a physical sign location or derived from the state's road records.
